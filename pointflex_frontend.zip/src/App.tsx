import React, { useEffect, useState } from 'react'

function App() {
  const [message, setMessage] = useState('Chargement...')

  useEffect(() => {
    fetch('/api/hello')
      .then(res => res.json())
      .then(data => setMessage(data.message))
      .catch(() => setMessage('Erreur de connexion au backend'))
  }, [])

  return (
    <div style={{ textAlign: 'center', padding: '2rem' }}>
      <h1>PointFlex</h1>
      <p>{message}</p>
    </div>
  )
}

export default App
